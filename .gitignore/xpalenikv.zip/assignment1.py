import sys
from scapy.all import rdpcap
import ruamel.yaml
from  ruamel.yaml import YAML
import binascii
import yaml

class Packet:
    
    def __init__(self, hex_frame, frame_number, protocols):

        self.frame = bytes(hex_frame)
        self.frame_number = frame_number+1
        
        hex_string = binascii.hexlify(self.frame).decode('utf-8')
        byte_groups = [hex_string[i:i+2].upper() for i in range(0, len(hex_string), 2)]
        separated_bytes = ' '.join(byte_groups)
        lines = [separated_bytes[i:i+48] for i in range(0, len(separated_bytes), 48)]
        lines = [line.rstrip() for line in lines]
        done = '\n'.join(lines)
        done = done + '\n'
        self.hexa_frame = ruamel.yaml.scalarstring.LiteralScalarString(done)
        
        dst_str = binascii.hexlify(self.frame[0:6]).decode('utf-8')
        dst_bytes = [dst_str[i:i+2].upper() for i in range(0, len(dst_str), 2)]
        self.dst_mac = ':'.join(dst_bytes)
        src_str = binascii.hexlify(self.frame[6:12]).decode('utf-8')
        src_bytes = [src_str[i:i+2].upper() for i in range(0, len(dst_str), 2)]
        self.src_mac = ':'.join(src_bytes)
        self.frame_length = len(self.frame)
        
        # length
        if len(hex_frame) + 4 < 64: 
            self.wire_lenght = 64
        else:
            self.wire_lenght = len(self.frame) + 4
            
        # ethernet II
        if int.from_bytes(self.frame[12:14], byteorder='big') >= 1536:
            self.frame_type = 'ETHERNET II'
            ether_type = int.from_bytes(self.frame[12:14], byteorder='big')
            self.ether_type = protocols['ether_type'].get(ether_type, 'unknown')
        # IEEE 802.3
        else:
            # AA
            if int(self.frame[14]) == 170:
                self.frame_type = 'IEEE 802.3 LLC & SNAP'
                pid = int.from_bytes(self.frame[20:22], byteorder='big')
                self.pid = protocols['pid'].get(pid, 'unknown')
            # FF
            elif int(self.frame[14]) == 255:
                self.frame_type = 'IEEE 802.3 RAW'
            # it must be LLC now
            else:
                self.frame_type = 'IEEE 802.3 LLC'
                sap = int(self.frame[14])
                self.sap = protocols['sap'].get(sap, 'unknown')
        
        if self.frame_number == 18:
            print(self.hexa_frame[20:22])
            print(int.from_bytes(self.frame[20:22], byteorder='big'))
            pid = int.from_bytes(self.frame[20:22], byteorder='big')
            print(pid)

        
    
def extract_hexadecimal_data(pcap_file, protocols):
    packets = rdpcap(pcap_file)

    packets_list = []

    for index, packet in enumerate(packets):
        packet = Packet(packet, index, protocols)
        packets_list.append(packet)

    return packets_list


def load_protocols(protocols_file):
    with open(protocols_file, 'r') as file:
        data = ruamel.yaml.safe_load(file)

    return data
                

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python assignment1.py <pcap_file>")
        sys.exit(1)

    pcap_file = sys.argv[1]
    protocols_file = 'protocols.yaml'

    
    protocols = load_protocols(protocols_file)
    print(protocols['pid'])
    packets_list = extract_hexadecimal_data(pcap_file, protocols)

    print_packets = []
    
    for packet in packets_list:
        dict = {
            'frame_number': packet.frame_number,
            'len_frame_pcap': packet.frame_length,
            'len_frame_medium': packet.wire_lenght,
            'frame_type': packet.frame_type,
            'src_mac': packet.src_mac,
            'dst_mac': packet.dst_mac
        }
        # if hasattr(packet, 'ether_type'):
        #     dict['ether_type'] = packet.ether_type
            
        if hasattr(packet, 'sap'):
            dict['sap'] = packet.sap
        
        if hasattr(packet, 'pid'):
            dict['pid'] = packet.pid
            
        dict['hexa_frame'] = packet.hexa_frame
        print_packets.append(dict)
        
    output_data = {
        'name': 'PKS2023/24',
        'pcap_name': f'{pcap_file}',
        'packets': print_packets,
    }
    
    yaml = YAML()
    output_file = 'output.yaml'
    with open(output_file, 'w') as file:
        yaml.dump(output_data, file)
